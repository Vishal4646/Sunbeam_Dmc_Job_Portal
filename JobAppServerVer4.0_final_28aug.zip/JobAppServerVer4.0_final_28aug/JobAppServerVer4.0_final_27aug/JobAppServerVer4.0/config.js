module.exports = {
    email: {
      user: 'aniketfulzele848@gmail.com',
      password: 'khnaznxqgsloauiq',
    },
  }