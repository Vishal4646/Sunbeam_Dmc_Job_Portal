export const constants = {
    serverUrl: 'http://13.233.196.80:4001',
  }

  